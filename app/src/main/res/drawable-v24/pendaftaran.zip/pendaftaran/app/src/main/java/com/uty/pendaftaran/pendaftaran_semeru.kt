package com.uty.pendaftaran

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class pendaftaran_semeru : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pendaftaran_semeru)
    }
}
